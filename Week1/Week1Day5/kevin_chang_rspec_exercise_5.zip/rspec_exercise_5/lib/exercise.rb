def zip(*arr)
    new_arr = []
    i = 0
    while i < arr[0].length
        temp = []
        arr.each do |subarray|
            temp << subarray[i]
        end
        new_arr << temp
        i += 1
    end
    new_arr
end

def prizz_proc(arr, prc1, prc2)
    result = []
    arr.each do |e|
        if prc1.call(e) != prc2.call(e)
            result << e 
        end
    end
    return result
end

def zany_zip(*arr)
    max_length = 0
    arr.each do |x|
        if x.length > max_length
            max_length = x.length
        end
    end
    result = []
    i = 0
    while i < max_length
        temp = []
        arr.each do |subarray|
            if i > subarray.length - 1
                temp << nil
            else
                temp << subarray[i]
            end
        end
        result << temp
        i += 1
    end
    result
end

def maximum(arr, &prc)
    return nil if arr.empty?
    current_ele = nil
    current_max = nil
    arr.each do |ele|
        value = prc.call(ele)
        if current_max == nil || value >= current_max
            current_max = value
            current_ele = ele
        end
    end
    current_ele
end

def my_group_by(array, &prc)
    hash = {}
    array.each do |ele|
        value = prc.call(ele)
        if hash.has_key?(value)
            hash[value] << ele
        else  
            hash[value] = [ele]
        end 
    end
    hash  
end

#READTHISAGAIN
def max_tie_breaker(array, proc, &block)
    max = nil 
    result = nil 
    # 3, 3, 7, 10
    array.each do |ele|
        value = block.call(ele)
       if (max == nil) || (value > max)
            max = value
            result = ele  
       elsif  value == max  
            proc_value1 = proc.call(ele)
            proc_value2 = proc.call(result)
            if proc_value1 > proc_value2
                max = value  
                result = ele  
            end 
       end 
    end 
    result 
end

def vowel_count(word)
    count = 0 
    vowels = "aeiouAEIOU"
    word.each_char {|char| count += 1 if vowels.include?(char) }
    count 
end 

def remove(word)
    vowels = "aeiouAEIOU"
    first_index = nil 
    last_index = nil 
    word.each_char.with_index do |char, idx|
        if vowels.include?(char)
            last_index = idx  
            if first_index == nil   
                first_index = idx 
            end 
        end 
    end 
    word[first_index..last_index]
end 

def silly_syllables(sentence)
    parts = sentence.split(" ")
    parts.map do |word|
        if vowel_count(word) > 1  
            remove(word)
        else  
            word  
        end
    end.join(" ")
end